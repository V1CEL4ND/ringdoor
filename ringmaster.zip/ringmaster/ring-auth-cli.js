#!/usr/bin/env node
require('./lib/api/refresh-token').acquireRefreshToken()
