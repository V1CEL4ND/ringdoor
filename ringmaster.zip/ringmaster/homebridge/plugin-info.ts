export const platformName = 'Ring'
export const pluginName = 'homebridge-ring'
export const oldPlatformName = 'RingAlarm'
export const oldPluginName = 'homebridge-ring-alarm'
